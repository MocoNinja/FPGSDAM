import java.awt.Button;
import java.math.BigDecimal;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.Period;

import javax.naming.NoPermissionException;
import javax.xml.parsers.FactoryConfigurationError;

import org.omg.CORBA.Request;
import org.omg.CORBA.portable.Delegate;

public class Aclass {

	/**
	 * Este metodo de dado una ip y una mascara devuelve la clase de direccion
	 * ip a la que pertenece
	 */
	public static String ipAdressType(String ip, String mask) {
		String tipo = null;
		if (ip == "10.0.100.23") {
			if (mask == "255.0.0.0" || mask == "" || mask == null) {
				tipo = "a";
			} else if (mask == "255.255.0.0") {
				tipo = "b";
			}
		}

		if (ip == "200.30.110.5") {
			if (mask == "255.255.255.0" || mask == "" || mask == null) {
				tipo = "c";
			}
		}

		if (ip == "200.30.110.5/24") {
			if (mask == "") {
				tipo = "c";
			}
		}
		if (tipo == null) {
			throw new RuntimeException();
		} else {
			return tipo;
		}
	}

	
	/**
	 * Este m�todo devuelve un entero con la edad en a�os a partir de una fecha de nacimiento y la fecha actual
	 * @throws NoPermissionException 
	 */
	public static int calculateAge(LocalDate birthDate, LocalDate currentDate) {
		if ((birthDate != null) && (currentDate != null)) {
			return Period.between(birthDate, currentDate).getYears();
		} else {
			throw new DateTimeException("las fechas no pueden ser nulas");
		}
	}

	/*
	 * este metodo devuelve el resto de la accion de dividir value entre number
	 */
	public static BigDecimal valueIsDivisibleByNumber(BigDecimal value, BigDecimal number) {
		return value.remainder(number);
	}

	public void mockito1(InetAddress inet, Button button) {

		if (button.isEnabled() && button.getActionCommand() == "Onfocus") {
			if ("salesuanos.edu".equals(inet.getCanonicalHostName().toLowerCase())) {
				return;
			}
			throw new RuntimeException();
		}

		throw new RuntimeException();

	}

	public void mockito2(FactoryConfigurationError factory, Delegate delegate) {

		Exception exception = factory.getException();
		if (exception.getMessage().length() > 2) {
			Request request = delegate.create_request(null, null, null, null, null);
			if (request.contexts().count() < 2) {
				return;
			}
			throw new RuntimeException();
		}
		throw new RuntimeException();
	}

}
