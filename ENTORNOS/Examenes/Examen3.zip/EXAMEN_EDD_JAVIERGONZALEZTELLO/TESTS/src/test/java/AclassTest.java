
import static org.junit.Assert.*;

import java.awt.Button;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.time.LocalDate;

import javax.xml.parsers.FactoryConfigurationError;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.omg.CORBA.ContextList;
import org.omg.CORBA.Request;
import org.omg.CORBA.portable.Delegate;

@RunWith(MockitoJUnitRunner.class)
public class AclassTest {

	Aclass clase = new Aclass();
	
	@Mock
	InetAddress ipfalsa;
	
	@Mock
	Button botonfalso;
	
	@Mock
	Exception mensajefake;
	
	@Mock
	FactoryConfigurationError factoria;
	
	@Mock
	Delegate delegateque;
	
	@Mock 
	Request requestque;
	
	@Mock
	ContextList listaque;
	
	@Test
	public void testIPADRESSTYPE() {
		// Tests para el correcto funcionamiento del programa
		
		Assert.assertEquals("a", clase.ipAdressType("10.0.100.23", null));
		Assert.assertEquals("a", clase.ipAdressType("10.0.100.23", ""));
		Assert.assertEquals("a", clase.ipAdressType("10.0.100.23", "255.0.0.0"));
		Assert.assertEquals("b", clase.ipAdressType("10.0.100.23", "255.255.0.0"));
		
		Assert.assertEquals("c", clase.ipAdressType("200.30.110.5", null));
		Assert.assertEquals("c", clase.ipAdressType("200.30.110.5", ""));
		Assert.assertEquals("c", clase.ipAdressType("200.30.110.5", "255.255.255.0"));
		
		Assert.assertEquals("c", clase.ipAdressType("200.30.110.5/24", ""));
		
		//  Test de las excepciones
		
		try{
			clase.ipAdressType(null, null);
			System.out.println("Lo anterior he petado y debería catcherase");
			fail();
		}catch (Exception e) {
			System.out.println("Trap avoided");
		}
		
		try{
			clase.ipAdressType("hola", "3434");
			System.out.println("Lo anterior he petado y debería catcherase");
			fail();
		}catch (Exception e) {
			System.out.println("Trap avoided");
		}
		
		try{
			clase.ipAdressType("puro bait", "255.0.0.0");
			System.out.println("Lo anterior he petado y debería catcherase");
			fail();
		}catch (Exception e) {
			System.out.println("Trap avoided");
		}
		try{
			clase.ipAdressType("10.0.232.0", "255.255.0.0");
			System.out.println("Lo anterior he petado y debería catcherase");
			fail();
		}catch (Exception e) {
			System.out.println("Trap avoided");
		}
	}

	@Test
	public void testCALCULATEAGE() {
		LocalDate hoy  = LocalDate.now();
		LocalDate miCumple = LocalDate.of(1993, 4, 1);
		assertEquals(24, clase.calculateAge(miCumple, hoy));
		
		try{
			LocalDate miCumpleFallido = null;
			clase.calculateAge(miCumpleFallido, hoy);
			fail();
		}catch (Exception e) {
			System.out.println("Esquivao");
		}
		try{
			LocalDate hoyFallido = null;
			clase.calculateAge(miCumple, hoyFallido);
			fail();
		}catch (Exception e) {
			System.out.println("Esquivao");
		}
		try{
			LocalDate falso = null;
			clase.calculateAge(falso, falso);
			fail();
		}catch (Exception e) {
			System.out.println("Esquivao");
		}
	}
	
	@Test
	public void testISDIVISIBLE() {
		BigDecimal numeroTocho1 = new BigDecimal("342423423424242");
		BigDecimal numeroTocho2 = new BigDecimal("3423");
		try{
			clase.valueIsDivisibleByNumber(numeroTocho1, numeroTocho2);
		} catch (Exception e) {
			System.out.println("Lo de antes no petaba");
			fail();
		}
		BigDecimal numero1 = new BigDecimal("4");
		BigDecimal numero2 = new BigDecimal("2");
		BigDecimal expected = new BigDecimal("0");
		assertEquals(expected, clase.valueIsDivisibleByNumber(numero1, numero2));
		
		/*  // EL constructor peta directamente, así que el test no tiene sentido
		BigDecimal numeroTocho3 = new BigDecimal("Rica trampa");
		BigDecimal numeroTocho4 = new BigDecimal("3423");
		try{
			clase.valueIsDivisibleByNumber(numeroTocho1, numeroTocho2);
			//fail();
		} catch (Exception e) {
			System.out.println("Lo de antes petaba");
		}
		*/
	}

	@Test
	public void testMoco1(){
		Mockito.when(botonfalso.isEnabled()).thenReturn(true);
		Mockito.when(botonfalso.getActionCommand()).thenReturn("Onfocus");
		Mockito.when(ipfalsa.getCanonicalHostName()).thenReturn("SALESUANOS.EDU");
		try{
			clase.mockito1(ipfalsa, botonfalso);
			System.out.println("Mock pasao");
		} catch (Exception e) {
			System.out.println("Si peta, esta mal mockeao");
			fail();
		}
	}
	
	@Test
	public void testMoco2(){
		// factoria
		Mockito.when(factoria.getException()).thenReturn(mensajefake);
		//excepcion
		Mockito.when(mensajefake.getMessage()).thenReturn("Esto tiene claramente más de 2 caracteres");
		//delegate -> request
		Mockito.when(delegateque.create_request(null, null, null, null, null)).thenReturn(requestque);
		Mockito.when(requestque.contexts()).thenReturn(listaque);
		Mockito.when(listaque.count()).thenReturn(1);
		
		try{
			clase.mockito2(factoria, delegateque);
			System.out.println("Mock pasao");
		} catch (Exception e) {
			System.out.println("Si peta, esta mal mockeao");
			fail();
		}
		
	}
	
	
}
